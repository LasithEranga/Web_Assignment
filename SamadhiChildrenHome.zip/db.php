<?php
$Con = mysqli_connect("localhost", "root", "", "samadi_children_home","3306");
?>